    <!-- FONTELLO -->
    <link rel="stylesheet" href="../../src/plugin/fontello/css/fontello.css">
    <link rel="stylesheet" href="../../src/plugin/fontello/css/animation.css">

    <!-- BOOTSTRAP -->
    <link rel="stylesheet" href="../../src/plugin/bootstrap-5/css/bootstrap.min.css">

    <!-- SWEETALERT -->
    <link rel="stylesheet" href="../../src/plugin/sweetalert2/sweetalert2.min.css">

    <!-- DATATABLES -->
    <link rel="stylesheet" href="../../src/plugin/datatables/dataTables.responsive.min.css">
    <link rel="stylesheet" href="../../src/plugin/datatables/1.13.6/css/dataTables.bootstrap5.min.css">

    <!-- DATERANGEPICKER -->
    <link rel="stylesheet" href="../../src/plugin/daterangepicker/daterangepicker.css">

    <!-- SELECT2 -->
    <link rel="stylesheet" href="../../src/plugin/select2/bootstrap/select2.min.css">
    <link rel="stylesheet" href="../../src/plugin/select2/bootstrap/select2-bootstrap-5-theme.min.css">

    <!-- PERSONALIZADO -->
    <link rel="stylesheet" href="../../src/css/navbar.css">
    <link rel="stylesheet" href="../src/css/usuarios.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">


